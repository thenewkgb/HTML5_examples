document.getElementsByTagName('h1')[0].onmouseover =
function () {
this.innerText='QWERTY' ; this.style.color='Black' }

document.getElementsByTagName('h1')[0].onmouseout =
function () {
this.innerText='QWERTY' ; this.style.color=`Blue`}